'''
main.py
Jr. IS Software: Graph Centrality CentralityApplication
Spring '18 CS120- The College of Wooster

Writen by Scott Stoudt
'''
from Tkinter import *
import tkMessageBox
from tkFileDialog import *
import networkx as nx
import matplotlib
import csv
matplotlib.use("TkAgg")
from matplotlib import pyplot as plt

class CentralityApplication:
    global senderList
    senderList = []
    global receiverList
    receiverList = []
    global centralityList
    centralityList = []
    global G
    global degVals
    degVals = []
    global betVals
    betVals = []
    global closeVals
    closeVals = []
    def upload(self):
        #asks for file to be analyzed (csv in this case)
        filename = askopenfilename(initialdir = "/Desktop",title = "Select file",filetypes = (("csv files","*.csv"),("all files","*.*")))

        #reset all variables
        self.clearGraph()

        #checks if upload was successful or not
        if(filename != ''):
            self.label.configure(text = "Upload successful!")
            self.graph1_button.configure(state=NORMAL)
            self.graph2_button.configure(state=NORMAL)
            self.graph3_button.configure(state=NORMAL)
            self.info_button.configure(state=NORMAL)
            #reads in senders/receivers from csv to create lists of each
            with open(filename, 'rU') as csvData:
                nr = csv.reader(csvData)
                for row in nr:
                    temp1 = str(row[0])
                    temp2 = str(row[1])
                    senderList.append(temp1)
                    receiverList.append(temp2)
                self.makeGraph(senderList, receiverList)
        else:
            self.label.configure(text = "Upload not successful!")
            self.graph1_button.configure(state=DISABLED)
            self.graph2_button.configure(state=DISABLED)
            self.graph3_button.configure(state=DISABLED)
            self.info_button.configure(state=DISABLED)

    #Creates the graph using senders/receivers as nodes
    #Then creates an edge from the sender to its appropriate receiver
    def makeGraph(self,senderList,receiverList):
        global G
        G = nx.Graph()

        for i in range(len(senderList)):
            G.add_edge(senderList[i], receiverList[i])

    #makes the matplotlib graph visible
    def showGraph(self, values):
        valMap = [values[node] for node in G.nodes()]
        nameMap = G.nodes()
        #assigns color of node based on desired centrality value
        nx.draw(G, with_labels=True, node_color=valMap , cmap=plt.cm.jet)
        plt.show()

    #calls for calculation of degree centrality values and sends the
    #values to be used to make the graph
    def degButton(self):
        plt.clf()
        self.graph1_button.configure(state=DISABLED)
        self.graph2_button.configure(state=NORMAL)
        self.graph3_button.configure(state=NORMAL)
        self.calculateDegree()
        self.showGraph(degVals)

    #calls for calculation of betweenness centrality values and sends the
    #values to be used to make the graph
    def betButton(self):
        plt.clf()
        self.graph1_button.configure(state=NORMAL)
        self.graph2_button.configure(state=DISABLED)
        self.graph3_button.configure(state=NORMAL)
        self.calculateBetween()
        self.showGraph(betVals)

    #calls for calculation of cloeness centrality values and sends the
    #values to be used to make the graph
    def closeButton(self):
        plt.clf()
        self.graph1_button.configure(state=NORMAL)
        self.graph2_button.configure(state=NORMAL)
        self.graph3_button.configure(state=DISABLED)
        self.calculateCloseness()
        self.showGraph(closeVals)

    #calculates degree centrality of all nodes in graph G
    def calculateDegree(self):
        #dictionary with 'node_name':'centrality value'
        global degVals
        #uses networkx function to calculate centrality values for each nodes
        #with respect to all other nodes in graph G
        ###exact formula used is discussed in paper portion
        degVals = nx.degree_centrality(G)

    #calculates betweenness centrality of all nodes in graph G
    def calculateBetween(self):
        #dictionary with 'node_name':'centrality value'
        global betVals
        betVals = nx.betweenness_centrality(G)

    #calculates cloeness centrality of all nodes in graph G
    def calculateCloseness(self):
        #dictionary with 'node_name':'centrality value'
        global closeVals
        closeVals = nx.closeness_centrality(G)

    #resets all lists, graph, etc. when a new csv is linked to the program
    def clearGraph(self):
        global senderList
        senderList = []
        global receiverList
        receiverList = []
        global centralityList
        centralityList = []
        global degVals
        degVals = []
        global betVals
        betVals = []
        global closeVals
        closeVals = []

    #Creates a pop up message to explain what the colors of the nodes in the graph mean
    def tipPopup(self):
        tkMessageBox.showinfo("Node Color Info", "The closer a node is to RED, the higher the centrality. The closer a node is to BLUE, the lower the centrality.")


    #creation of the tkinter GUI
    def __init__(self, master):
        self.master = master
        master.title("Graph Centrality Application - Scott Stoudt")

        self.label = Label(master, text="Please upload the csv file you would like to analyze!")
        self.label.configure(font=('helvetica', 20, 'italic'))
        self.label.grid(row=0, column=0, columnspan=3, pady=20)

        self.upload_button = Button(master, text="Upload", command=self.upload)
        self.upload_button.grid(row=1, column=1, columnspan=1)

        self.graph1_button = Button(master, text="Degree Centrality", command=self.degButton, state =DISABLED)
        self.graph2_button = Button(master, text="Betweenness Centrality", command=self.betButton, state =DISABLED)
        self.graph3_button = Button(master, text="Closeness Centrality", command=self.closeButton, state =DISABLED)

        self.graph1_button.grid(row=2, column=0, columnspan=1, pady=30, padx=(30,10))
        self.graph2_button.grid(row=2, column=1, columnspan=1, pady=10, padx=10)
        self.graph3_button.grid(row=2, column=2, columnspan=1, pady=10, padx=(10,30))

        self.info_button = Button(master, text= 'Analysis Help', command=self.tipPopup, state =DISABLED)
        self.info_button.grid(row=3, column=0, padx=(30,10))

        self.close_button = Button(master, text="Quit Application", command=root.destroy)
        self.close_button.grid(row=3, column=2, columnspan=1, padx=(10,30))


#Main window tkinter sizing/positioning
root = Tk()
RWidth = root.winfo_screenwidth()
RHeight = root.winfo_screenheight()
root.geometry(("%dx%d+%d+%d")%(RWidth/3,RHeight/4,RWidth-550,0))
root.minsize(550, 250)
root.maxsize(550, 250)
my_gui = CentralityApplication(root)
root.mainloop()
